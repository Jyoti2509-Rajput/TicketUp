
    <footer class="footer bg-dark text-light p-3">
      <div class="ct text-center fw-bold text-secondary" style="font-size: 13px;">
        Copyrights &copy; 2022 | TicketUp.com All Rights Reserved
      </div>
    </footer>